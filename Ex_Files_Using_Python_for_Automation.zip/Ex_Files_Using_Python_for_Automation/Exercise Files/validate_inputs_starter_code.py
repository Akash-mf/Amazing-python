import pyinputplus as pyip

print("\nEXAMPLE 1")

# uncomment the following line of code and fill in 
# result = 

# uncomment the following line of code
# print("\nYou will use", result, "store bags.")

print("\nEXAMPLE 2")

# uncomment the following line of code and fill in 
# result = 

# uncomment the following line of code
# print("\nYou have chosen a", result, "marker.")

print("\nEXAMPLE 3")

# uncomment the following line of code and fill in 
# result = 

# uncomment the following line of code
# print("\nThe email you entered:", result)