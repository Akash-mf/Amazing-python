# import relevant libraries
import requests
from bs4 import BeautifulSoup

# define the url
# FILL IN before running the code
url = "FILL IN"

# send a request to get html code from that url
# uncomment the following line and replace with your code
# response = FILL IN

# parse the response
# uncomment the following line and replace with your code
# parsed_response = FILL IN

# format the parsed HTML response in a way that’s easier to read and print it out
# uncomment the following line before running the code
# print(parsed_response.prettify())