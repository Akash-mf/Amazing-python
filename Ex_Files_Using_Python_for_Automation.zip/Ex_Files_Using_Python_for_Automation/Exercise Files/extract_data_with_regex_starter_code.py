import re

# uncomment the following line of code and fill in 
# phoneNumRegex =

example = "The number is 123-456-7890."

# uncomment the following line of code and fill in 
# result =

# uncomment the following lines of code and fill in 
# if result:
#     print("Phone number found:", # FILL IN #)
#     print("Area code:", # FILL IN #)