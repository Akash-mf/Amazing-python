import subprocess

for i in range(5):
    subprocess.check_call(["python3", "example.py"])