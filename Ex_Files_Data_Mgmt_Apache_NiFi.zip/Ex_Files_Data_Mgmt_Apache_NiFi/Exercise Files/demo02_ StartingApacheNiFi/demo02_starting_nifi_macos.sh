-------------------------------------------------------------------------
Install and set up NiFi
-------------------------------------------------------------------------



# Open a terminal

$ cd ~/tools/nifi-1.22.0/


$ ls -l bin/

#  Notes ----------------------
# For Windows users, navigate to the folder where NiFi was installed. Within this folder is a subfolder named bin. Navigate to this subfolder and double-click the run-nifi.bat file.

# This will launch NiFi and leave it running in the foreground. To shut down NiFi, select the window that was launched and hold the Ctrl key while pressing C.
#  Notes ----------------------


$ ./bin/nifi.sh --help
# Usage nifi {start|stop|decommission|run|restart|status|dump|diagnostics|status-history|install|stateless|set-sensitive-properties-algorithm|set-sensitive-properties-key|set-single-user-credentials}


$ ./bin/nifi.sh status
# INFO [main] org.apache.nifi.bootstrap.Command Apache NiFi is not running


# Open up in Sublimetext
> Go to conf/nifi.properties

# Change from port 8443 to 8444
nifi.web.https.port=8444

# Notes ---------------------------
# To run NiFi in the foreground, run bin/nifi.sh run. This will leave the application running until the user presses Ctrl-C. At that time, it will initiate shutdown of the application.
# Notes ---------------------------


# Run NiFi in the backgroud

$ ./bin/nifi.sh start
# Java home: /Library/Java/JavaVirtualMachines/jdk-11.0.13.jdk/Contents/Home
# NiFi home: /Users/loonycorn/tools/nifi-1.20.0
# Bootstrap Config File: /Users/loonycorn/tools/nifi-1.20.0/conf/bootstrap.conf



$ ./bin/nifi.sh status
# Java home: /Library/Java/JavaVirtualMachines/jdk-11.0.13.jdk/Contents/Home
# NiFi home: /Users/loonycorn/tools/nifi-1.20.0
# Bootstrap Config File: /Users/loonycorn/tools/nifi-1.20.0/conf/bootstrap.conf
# 2023-04-03 16:07:06,910 INFO [main] org.apache.nifi.bootstrap.Command Apache NiFi is currently running, listening to Bootstrap on port 61688, PID=67082


$ less ~/tools/nifi-1.20.0/logs/nifi-bootstrap.log
# org.apache.nifi.bootstrap.Command Launched Apache NiFi with Process ID 67082
# INFO [NiFi Bootstrap Command Listener] org.apache.nifi.bootstrap.RunNiFi Apache NiFi now running and listening for Bootstrap requests on port 61688

:q to exit


# Notes ----------------------

# The web browser will display a warning message indicating a potential security risk due to the self-signed certificate NiFi generated during initialization. Accepting the potential security risk and continuing to load the interface is an option for development installations. The self-signed certificate will expire after 60 days. Production deployments should provision a certificate from a trusted authority and update the NiFi keystore and truststore configuration.

# Notes ----------------------


# In browser
> Goto https://127.0.0.1:8444/nifi

# Here they ask for username and password

# Back to the terminal window
# The username and password are generated in random
$ less logs/nifi-app.log

$ cat logs/nifi-*.log | grep "Generated"
# Generated Username [31d0430a-d298-4e71-b6b4-1cc4917843bf]
# Generated Password [py4VpLxPe1U1oBZJvIWa0Ca1VY9h8uFa]

# Let's change the username and password so we can remember it

> Go back to the terminal

# We can use the below command to create our own username and password
$ ./bin/nifi.sh set-single-user-credentials loonycorn loonypassword
# Java home: /Library/Java/JavaVirtualMachines/jdk-11.0.13.jdk/Contents/Home
# NiFi home: /Users/loonycorn/tools/nifi-1.20.0
# Bootstrap Config File: /Users/loonycorn/tools/nifi-1.20.0/conf/bootstrap.conf
# Login Identity Providers Processed [/Users/loonycorn/tools/nifi-1.20.0/./conf/login-identity-providers.xml]


$ ./bin/nifi.sh restart
# Java home: /Library/Java/JavaVirtualMachines/jdk-11.0.13.jdk/Contents/Home
# NiFi home: /Users/loonycorn/tools/nifi-1.20.0
# Bootstrap Config File: /Users/loonycorn/tools/nifi-1.20.0/conf/bootstrap.conf
# INFO [main] org.apache.nifi.bootstrap.Command Apache NiFi has accepted the Shutdown Command and is shutting down now
# INFO [main] org.apache.nifi.bootstrap.Command NiFi PID [74745] shutdown in progress...
# INFO [main] org.apache.nifi.bootstrap.Command NiFi PID [74745] shutdown completed

# Java home: /Library/Java/JavaVirtualMachines/jdk-11.0.13.jdk/Contents/Home
# NiFi home: /Users/loonycorn/tools/nifi-1.20.0
# Bootstrap Config File: /Users/loonycorn/tools/nifi-1.20.0/conf/bootstrap.conf


$ ./bin/nifi.sh status
# Java home: /Library/Java/JavaVirtualMachines/jdk-11.0.13.jdk/Contents/Home
# NiFi home: /Users/loonycorn/tools/nifi-1.20.0
# Bootstrap Config File: /Users/loonycorn/tools/nifi-1.20.0/conf/bootstrap.conf
# INFO [main] org.apache.nifi.bootstrap.Command Apache NiFi is currently running, listening to Bootstrap on port 65450, PID=77231



> Go back to "https://127.0.0.1:8444/nifi/login"

User: loonycorn
Password: loonypassword


# Show the main page

- Hover over each element in the components toolbar
- Click on the global menu (top right) and show



# understanding nifi user interface
# https://nifi.apache.org/docs/nifi-docs/html/getting-started.html#i-started-nifi-now-what
# https://docs.cloudera.com/HDPDocuments/HDF3/HDF-3.0.0/bk_user-guide/content/User_Interface.html#:~:text=%E2%80%8BNiFi%20User%20Interface,different%20functionality%20of%20the%20application.










