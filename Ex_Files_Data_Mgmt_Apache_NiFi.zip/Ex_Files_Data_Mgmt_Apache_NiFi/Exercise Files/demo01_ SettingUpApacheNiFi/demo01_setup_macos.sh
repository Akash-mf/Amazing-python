-------------------------------------------------------------------------
Install and set up NiFi
-------------------------------------------------------------------------


-------------------------
Make sure Java is installed 
-------------------------


# https://nifi.apache.org/

# Make sure you have Java installed

# Open a terminal
$ java -version

# java version "11.0.13" 2021-10-19 LTS
# Java(TM) SE Runtime Environment 18.9 (build 11.0.13+10-LTS-370)
# Java HotSpot(TM) 64-Bit Server VM 18.9 (build 11.0.13+10-LTS-370, mixed mode)

$ /usr/libexec/java_home -v 11
# /Library/Java/JavaVirtualMachines/jdk-11.0.13.jdk/Contents/Home

# It is not set in my case
$ echo $JAVA_HOME

$ nano ~/.bash_profile

$ export JAVA_HOME=/Library/Java/JavaVirtualMachines/jdk-11.0.13.jdk/Contents/Home

$ source ~/.bash_profile

$ echo $JAVA_HOME
# /Library/Java/JavaVirtualMachines/jdk-11.0.13.jdk/Contents/Home


-------------------------
Download NiFi
-------------------------

# > Goto to "https://nifi.apache.org/download.html"

# Latest version right now
* Version 1.22.0

# > Download from the "Binaries" version

# Make sure the Downloads folder is empty and does not have other stuff

# > Click "Apache NiFi Binary 1.22.0" > "https://dlcdn.apache.org/nifi/1.22.0/nifi-1.22.0-bin.zip"


$ mkdir ~/tools

$ mv ~/Downloads/nifi-1.22.0-bin.zip tools/

# > Open up Finder window to the tools folder and unzip "nifi-1.22.0-bin.zip"

# In terminal

# Create tools folder in root if not present


# > Open "nifi-1.22.0" in a Finder window and show

# bin/: Contains scripts for starting, stopping, and managing NiFi.
# conf/: Contains configuration files for NiFi, such as nifi.properties, which specifies global settings, and flow.xml.gz, which contains the flow definition.
# docs/: Contains documentation for NiFi.
# lib/: Contains the libraries required by NiFi.









