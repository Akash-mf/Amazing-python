import random
import csv

from time import sleep
from faker import Faker

fake = Faker()

product_types = ['Ultrabook', 'Notebook']
companies = ['Apple', 'HP', 'Acer', 'Asus', 'Dell', 'Lenovo']


for j in range(100000, 200000):
    
    LAPTOPS_FILE_PATH = f'/Users/loonycorn/tools/datasets/laptops_{j}.csv'

    with open(LAPTOPS_FILE_PATH, 'w', newline='') as csvfile:
        writer = csv.writer(csvfile, delimiter=',')

        writer.writerow(['Id', 'Company', 'Product', 'TypeName', 'Price_euros'])
        
        for i in range(1, 50):
            writer.writerow([
                i + 1, 
                fake.company(), 
                fake.word(), 
                fake.random_element(product_types), 
                fake.pyfloat(3, 2, positive=True)
            ])

        print(f'laptops_{j}.csv created!')    
        sleep(1)
