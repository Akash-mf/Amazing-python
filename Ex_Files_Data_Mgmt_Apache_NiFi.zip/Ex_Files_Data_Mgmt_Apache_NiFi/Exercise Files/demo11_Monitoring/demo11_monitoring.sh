-------------------------------------------------------------------------
Monitoring
-------------------------------------------------------------------------

# activities file

# ${filename:append('.json')}


# Jolt specification

[
    {
        "operation": "shift", 
        "spec": {
            "activity": "activity",
            "type": "type"
        }
    }
]


# Output filename
activity${nextInt()}.json


# Output folder

/Users/loonycorn/tools/activities




# Monitoring

smtp.gmail.com

465

loony.test.001@gmail.com

alice@loonycorn.com


Message from NiFi - Dataflow activity status changed


Message from NiFi - Dataflow success

The flow has completed successfully!
