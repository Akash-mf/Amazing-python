-------------------------------------------------------------------------
Data flow Management and Reusability
-------------------------------------------------------------------------

# We will continue with the same flow as in the previous demo (get file, put to database, transform, and then write transformed data locally)


########### Templates

ConvertDBOutputToCSVAndUpdateFilename




########### Process groups

ConvertDBOutputToJSONAndUpdateFilename


DatabaseQueryOutput


CSVDataUpdatedFilename

































