-------------------------------------------------------------------------
Text to copy-paste to avoid spelling mistakes
-------------------------------------------------------------------------

SimpleNiFiFlowTemplate


A template specification of a very simple flow. This is how all flows are stored in this course


########################################### NOTES ####################################

# Apache NiFi offers the concept of Templates, which makes it easier to reuse and distribute the NiFi flows. The flows can be used by other developers or in other NiFi clusters. It also helps NiFi developers to share their work in repositories like GitHub.

# NiFi templates are a powerful feature in Apache NiFi that allows users to define and share reusable dataflow configurations. Templates capture the configuration of NiFi processors, connections, and settings, making it easy to replicate complex dataflow pipelines quickly.

#  A template can be thought of as a reusable sub-flow.

# here are a few important notes to remember when working with templates:

# Any properties that are identified as being Sensitive Properties (such as a password that is configured in a Processor) will not be added to the template. These sensitive properties will have to be populated each time that the template is added to the canvas.

# If a component that is included in the template references a Controller Service, the Controller Service will also be added to the template. This means that each time that the template is added to the graph, it will create a copy of the Controller Service.

########################################### NOTES ####################################
