-------------------------------------------------------------------------
SQL Transformation and Saving Results Locally
-------------------------------------------------------------------------

## IMPORTANT: Please look at the layout screenshots to see how to layout the flow neatly

## Minimize the "navigate" and "operate" boxes on the left

# In this demo we will clean up the data and perform group by operation and save the resultant
# data to the local file system


# Drag and drop "ExecuteSQL" process


SQL select query: 

DELETE FROM cars WHERE brand IS NULL 
OR price IS NULL 
OR body IS NULL 
OR mileage IS NULL 
OR engv IS NULL 
OR engtype IS NULL 
OR registration IS NULL 
OR year IS NULL 
OR model IS NULL 
OR drive IS NULL;



# Drag and drop one more "ExecuteSQL" process

SQL select query: 

SELECT brand, AVG(price) as avg_price, COUNT(*) as count 
FROM cars GROUP BY brand



# Drag and drop "ConvertAvroToJson" process

JSON container options: array
Wrap Single Record: false
Avro schema: No value set



# Drag and drop "ConvertRecord" process

Record Reader: JsonTreeReader
Record Writer: CSVRecordSetWriter
Include Zero Record FlowFiles: true



# "JSONTREEREADER"
No change in the defaults


# "CSVRECORDSETWRITER"
No change in the defaults


# Drag and drop "UpdateAttribute" process
filename: grouped_${filename}


# Drag and drop "PutFile" process

Directory: /Users/loonycorn/tools/grouped_outputs
Conflict Resolution Strategy: replace
Create Missing Directories: true
Maximum File Count: No value set
Last Modified Time: No value set
Permissions: No value set
Owner: No value set
Group: No value set


