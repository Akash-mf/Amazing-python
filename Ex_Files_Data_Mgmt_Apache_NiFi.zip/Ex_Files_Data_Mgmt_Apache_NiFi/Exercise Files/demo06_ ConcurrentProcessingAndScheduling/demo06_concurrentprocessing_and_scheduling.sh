-------------------------------------------------------------------------
Concurrency and scheduling
-------------------------------------------------------------------------

# NULL values in the table
SELECT * 
FROM cars 
WHERE brand IS NULL 
OR price IS NULL 
OR body IS NULL 
OR mileage IS NULL 
OR engv IS NULL 
OR engtype IS NULL 
OR registration IS NULL 
OR year IS NULL 
OR model IS NULL 
OR drive IS NULL;


# Count of cars inserted so far
SELECT count(*) from cars;


















