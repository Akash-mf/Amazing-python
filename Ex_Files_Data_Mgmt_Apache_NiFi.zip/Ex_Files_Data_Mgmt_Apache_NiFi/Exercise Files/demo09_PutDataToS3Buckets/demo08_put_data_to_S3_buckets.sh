-------------------------------------------------------------------------
Put data to S3 buckets
-------------------------------------------------------------------------

---------------------------------------------------------
Set up the database on PostgreSQL
---------------------------------------------------------


# Open a terminal

$ psql

$ CREATE DATABASE laptops_db;

$ \c laptops_db


$ \dt

$ CREATE TABLE laptops (
  Id INT,
  Company VARCHAR(255),
  Product VARCHAR(255),
  TypeName VARCHAR(255),
  Price_euros FLOAT
);


$ \dt


---------------------------------------------------------
Create an S3 bucket and IAM user
---------------------------------------------------------

# Create an S3 bucket and set up a user with access permissions to S3

# Go to the AWS console (you can be logged in to start off with)

# Go to S3 and create a bucket

loony-nifi-laptop-bucket

# Accept all the default permissions (the bucket will be in the us-east-2 region)

# Go to IAM

# Create a user 

loony-nifi-user

# Attach policies directly

# To keep things simple we will set the following policy for the user


AmazonS3FullAccess

# Create the user


# Click through to the user -> Security Credentials

# Create and access key and copy the key and secret over


---------------------------------------------------------
Explore the NiFi flow
---------------------------------------------------------

## IMPORTANT
# Set up and configure the flow behind the scenes as you have done in the recording
# We will show how the whole flow looks and then show each step's configuration

# You can use the template XML file with this demo to set up the flow (just use the template and tweak anything you need before you record)

# Please make sure the flow is neat as in the screenshots


# Drag and drop "GetFile" process

Name: ReadLaptopDetails

Input Directory: /Users/loonycorn/tools/datasets
File Filter: laptops_[0-9]{6}\.csv


# Drag and drop "PutDatabaseRecord" process

Name: StoreLaptopDetailsInDB


# Please note that here I have reused the same CSV reader from the previous demo

Record Reader: CSVReader 
Database Type: PostgreSQL
Statement Type: INSERT
Database Connection Pooling Service: DBCPConnectionPool
Table Name: laptops
Treat First Line as Header: true #### IMPORTANT this is different

"CSVREADER"
Schema Access Strategy: Use 'Schema Text' Property
Schema Text: 
{
  "type": "record",
  "name": "laptops",
  "fields": [
    {"name":"Id", "type":["null", "int"]},
    {"name":"Company", "type":["null", "string"]},
    {"name":"Product", "type":["null", "string"]},
    {"name":"TypeName", "type":["null", "string"]},
    {"name":"Price_euros", "type":["null", "float"]}
  ]
}


# Please note that here I have reused the same DBCConnectionPool from the previous demo


"DBCPCONNECTIONPOOL"
Database Connection URL: jdbc:postgresql://localhost:5432/laptops_db
Database Driver Class Name: org.postgresql.Driver
Database Driver Location(s): /Users/loonycorn/tools/jdbc/postgresql-42.6.0.jar
Database User: loonycorn
Password: password


# Drag and drop "ExecuteSQL" process

Name: FilterUltrabookLaptops

Database Connection Pooling Service: DBCPConnectionPool
SQL select query: SELECT * FROM laptops WHERE TypeName = 'Ultrabook';


# Drag and drop "ExecuteSQL" process

Name: FilterNotebookLaptops

Database Connection Pooling Service: DBCPConnectionPool
SQL select query: SELECT * FROM laptops WHERE TypeName = 'Notebook';


# Drag and drop "ConvertAvroToJson" process
All default values, no change


# Drag and drop "ConvertAvroToJson" process
All default values, no change


# Drag and drop "UpdateAttribute" process
filename: ultrabook_${filename}.json

# Drag and drop "UpdateAttribute" process
filename: notebook_${filename}.json


# Drag and drop "PutS3Object" process

Name: PutUltrabookFilesInS3

Object Key: ${filename}
Bucket: loony-nifi-laptop-bucket
Access Secret Key: 
Secret Access Key: 
Region: US East (Ohio)


# Drag and drop "PutS3Object" process

Name: PutNotebookFilesInS3

Object Key: ${filename}
Bucket: loony-nifi-laptop-bucket
Access Secret Key: 
Secret Access Key: 
Region: US East (Ohio)


























