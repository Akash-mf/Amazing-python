-------------------------------------------------------------------------
Install and set up PostgreSQL
-------------------------------------------------------------------------


# Let's install postgresql first
# For that go to following link

https://postgresapp.com/downloads.html
# Click on the download button
# Now the dmg file will download to laptop, let's start installing that
# While installing we have to set a port, password and the owner name
# (note: in the latest version it did not ask me for a password)

# Show the page for downloading PostgreSQL on Windows and the tutorial
# (Do not actually download this we will NOT be showing Windows install)
https://www.postgresql.org/download/windows/

https://www.postgresqltutorial.com/postgresql-getting-started/install-postgresql/


# Once the download is complete on the local machine - complete the install by dragging to the Applications directory

# Start the Postgres server and show


# Back to the terminal window

# Set up the path for the command line (go to the terminal window and run this)

sudo mkdir -p /etc/paths.d &&
echo /Applications/Postgres.app/Contents/Versions/latest/bin | sudo tee /etc/paths.d/postgresapp


psql

# This should take you into the PSQL prompt

loonycorn=# 

# Type "quit" to exit


-------------------------------------------------------------------------
Set up a table to store data in PostgreSQL
-------------------------------------------------------------------------

# 

# Open a terminal
$ psql

$ CREATE DATABASE cars_db;

$ \c cars_ds


$ \dt



$ CREATE TABLE cars (
  brand varchar(255),
  price numeric,
  body varchar(255),
  mileage integer,
  engv numeric,
  engtype varchar(255),
  registration boolean,
  year integer,
  model varchar(255),
  drive varchar(255)
);


\dt
#          List of relations
#  Schema | Name | Type  |   Owner   
# --------+------+-------+-----------
#  public | cars | table | loonycorn



# Make sure that your dataset is in 

/Users/loonycorn/tools/datasets


# Open the csv files in "dataset" folder and look through it we can observe there are 
# some records which have "NA" records in a double column and there are some records 
# which have null values.


---------------------- GetFile --------------------------------

Input Directory: /Users/loonycorn/tools/datasets

File Filter: car_ad_[0-9]{2}\.csv

---------------------- PutDatabaseRecord --------------------------------


"CSVREADER"
Schema Access Strategy: Use 'Schema Text' Property
Schema Text: 
{
  "type": "record",
  "name": "cars",
  "fields": [
    {"name": "brand", "type": ["null", "string"]},
    {"name": "price", "type": ["null", "double"]},
    {"name": "body", "type": ["null", "string"]},
    {"name": "mileage", "type": ["null", "int"]},
    {"name": "engv", "type": ["null", "double"]},
    {"name": "engtype", "type": ["null", "string"]},
    {"name": "registration", "type": ["null", "string"]},
    {"name": "year", "type": ["null", "int"]},
    {"name": "model", "type": ["null", "string"]},
    {"name": "drive", "type": ["null", "string"]}
  ]
}

# Download the JDBC jar -> download java8 or newer

https://jdbc.postgresql.org/download/ 


"DBCPCONNECTIONPOOL"
Database Connection URL: jdbc:postgresql://localhost:5432/cars_db
Database Driver Class Name: org.postgresql.Driver
Database Driver Location(s): /Users/loonycorn/tools/jdbc/postgresql-42.6.0.jar


# SQL query to run

select * from cars;


---------------------- ReplaceText --------------------------------


Replacement Strategy: Literal Replace
Search Value: NA
Replacement Value: Empty string set
Character Set: UTF-8
Maximum Buffer Size: 1 MB
Evaluation Mode: Entire text
Line-by-Line Evaluation Mode: All




############################ NOTES ############################

# In Apache NiFi, Controller Services are a powerful mechanism to define and manage shared resources that can be utilized across multiple processors and components in a dataflow. They provide a way to centralize configuration and functionality, promoting reusability, consistency, and ease of maintenance in NiFi dataflows. Controller Services are particularly useful when you have certain configurations or services that need to be shared across multiple processors or when you want to encapsulate complex logic into a single, manageable component.

############################ NOTES ############################






















